-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 05-11-2013 a las 06:27:42
-- Versión del servidor: 5.0.67
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `bd_agua`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE IF NOT EXISTS `clientes` (
  `idc` int(11) NOT NULL auto_increment,
  `nombre_razon` varchar(250) NOT NULL,
  `dni_ruc` varchar(11) NOT NULL,
  `direccion` varchar(150) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `idz` int(11) NOT NULL,
  PRIMARY KEY  (`idc`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`idc`, `nombre_razon`, `dni_ruc`, `direccion`, `telefono`, `idz`) VALUES
(2, 'franco ur', '12345678', 'los pinos', '12345678', 1),
(3, 'oskrintall', '12345678', 'jr union', '123654', 2),
(4, 'Andrés García Macedo', '12345678', 'Jr. Union 147', '51945471121', 1),
(5, 'landon', '98765432', 'Jr peru', '123456', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detallemov`
--

CREATE TABLE IF NOT EXISTS `detallemov` (
  `iddetmov` int(11) NOT NULL auto_increment,
  `idmov` int(11) NOT NULL,
  `idmat` int(11) NOT NULL,
  `concepto` varchar(250) NOT NULL,
  `fecha` date NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `estado` int(11) NOT NULL COMMENT 'Estado 0 pendiente, 1 pagado',
  PRIMARY KEY  (`iddetmov`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Volcar la base de datos para la tabla `detallemov`
--

INSERT INTO `detallemov` (`iddetmov`, `idmov`, `idmat`, `concepto`, `fecha`, `cantidad`, `precio`, `estado`) VALUES
(1, 1, 1, 'Agua', '2013-11-05', 1, 3.00, 1),
(2, 1, 1, 'Agua', '2013-11-05', 2, 2.50, 1),
(3, 2, 1, 'Agua', '2013-10-25', 1, 4.00, 0),
(4, 2, 1, 'Agua', '2013-10-25', 2, 3.00, 0),
(5, 3, 1, 'Agua', '2013-11-05', 2, 3.00, 1),
(6, 3, 1, 'Agua', '2013-11-05', 1, 4.00, 1),
(7, 4, 1, 'Agua', '2013-11-05', 2, 3.00, 1),
(8, 4, 1, 'Agua', '2013-11-05', 1, 4.00, 1),
(9, 5, 1, 'Agua', '2013-11-05', 1, 2.00, 1),
(10, 6, 1, 'Agua', '2013-11-05', 1, 4.00, 1),
(11, 6, 1, 'Agua', '2013-11-05', 2, 3.50, 1),
(12, 6, 1, 'Agua', '2013-11-05', 1, 3.00, 1),
(13, 7, 1, 'Agua', '2013-11-05', 33, 2.00, 1),
(14, 7, 1, 'Agua', '2013-11-05', 1, 1.00, 1),
(15, 8, 1, 'Agua', '2013-11-05', 1, 4.00, 0),
(16, 8, 1, 'Agua', '2013-11-05', 1, 3.50, 0),
(17, 9, 1, 'Agua', '2013-11-05', 1, 4.00, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materiales`
--

CREATE TABLE IF NOT EXISTS `materiales` (
  `idmat` int(11) NOT NULL auto_increment,
  `descripcion` varchar(250) NOT NULL,
  PRIMARY KEY  (`idmat`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `materiales`
--

INSERT INTO `materiales` (`idmat`, `descripcion`) VALUES
(1, 'AGUA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimiento`
--

CREATE TABLE IF NOT EXISTS `movimiento` (
  `idmov` int(11) NOT NULL auto_increment,
  `idtm` int(11) NOT NULL,
  `idc` int(11) NOT NULL,
  `idusuario` int(11) NOT NULL,
  `fechamov` date NOT NULL,
  `estado` int(11) NOT NULL COMMENT '1:venta,0:credito',
  PRIMARY KEY  (`idmov`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Volcar la base de datos para la tabla `movimiento`
--

INSERT INTO `movimiento` (`idmov`, `idtm`, `idc`, `idusuario`, `fechamov`, `estado`) VALUES
(1, 1, 2, 5, '2013-10-25', 1),
(2, 1, 3, 5, '2013-10-25', 0),
(3, 1, 3, 5, '2013-10-26', 1),
(4, 2, 3, 5, '2013-10-26', 1),
(5, 2, 2, 5, '2013-10-26', 1),
(6, 2, 4, 5, '2013-11-05', 1),
(7, 2, 4, 5, '2013-11-04', 1),
(8, 2, 5, 5, '2013-11-05', 0),
(9, 1, 5, 5, '2013-11-05', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipomov`
--

CREATE TABLE IF NOT EXISTS `tipomov` (
  `idtm` int(11) NOT NULL auto_increment,
  `descripcion` varchar(250) NOT NULL,
  PRIMARY KEY  (`idtm`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `tipomov`
--

INSERT INTO `tipomov` (`idtm`, `descripcion`) VALUES
(1, 'contado'),
(2, 'credito');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipousuario`
--

CREATE TABLE IF NOT EXISTS `tipousuario` (
  `idtipousuario` int(11) NOT NULL auto_increment,
  `descripcion` varchar(100) default NULL,
  PRIMARY KEY  (`idtipousuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `tipousuario`
--

INSERT INTO `tipousuario` (`idtipousuario`, `descripcion`) VALUES
(5, 'ADMINISTRADOR');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `idusuario` int(11) NOT NULL auto_increment,
  `nombre` varchar(100) default NULL,
  `appat` varchar(100) default NULL,
  `apmat` varchar(100) default NULL,
  `direccion` varchar(250) default NULL,
  `telefono` varchar(30) default NULL,
  `edad` int(11) default NULL,
  `correo` varchar(150) default NULL,
  `login` varchar(50) default NULL,
  `contrasena` varchar(50) default NULL,
  `dni` varchar(8) default NULL,
  `sexo` int(11) NOT NULL,
  `idtipousuario` int(11) NOT NULL,
  PRIMARY KEY  (`idusuario`),
  KEY `fk_usuario_tipousuario1_idx` (`idtipousuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`idusuario`, `nombre`, `appat`, `apmat`, `direccion`, `telefono`, `edad`, `correo`, `login`, `contrasena`, `dni`, `sexo`, `idtipousuario`) VALUES
(5, 'FRANCO', 'USHIÑAHUA', 'REATEGUI', 'LOS PINOS 341', '123456', 26, 'fraure13@gmail.com', 'franko', '1', '44111072', 1, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zona`
--

CREATE TABLE IF NOT EXISTS `zona` (
  `idz` int(11) NOT NULL auto_increment,
  `descripcion` varchar(250) NOT NULL,
  PRIMARY KEY  (`idz`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `zona`
--

INSERT INTO `zona` (`idz`, `descripcion`) VALUES
(1, 'TARAPOTO'),
(2, 'MORALES'),
(3, 'BANDA DE SHILCAYO');

--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `fk_usuario_tipousuario1` FOREIGN KEY (`idtipousuario`) REFERENCES `tipousuario` (`idtipousuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;
